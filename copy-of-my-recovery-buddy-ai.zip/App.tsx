import React, { useState, useEffect } from 'react';
import { View, JournalEntry, MeetingLog, Contact, StepWork, Badge, Streak, UserProfile } from './types';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { AICoach } from './components/AICoach';
import { Journal } from './components/Journal';
import { StepWorkComponent } from './components/StepWork';
import { Readings } from './components/Readings';
import { Badges } from './components/Badges';
import { MeetingFinder } from './components/MeetingFinder';
import { Phone, AlertCircle, Siren, UserCircle, LogOut, LogIn } from 'lucide-react';
import { getCurrentUser, loadState, saveState, WPState, subscribeToJournals } from './services/backend';

const App: React.FC = () => {
  const [view, setView] = useState<View>(View.DASHBOARD);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // App Data State
  const [sobrietyDate, setSobrietyDate] = useState<string | null>(null);
  const [journals, setJournals] = useState<JournalEntry[]>([]);
  const [logs, setLogs] = useState<MeetingLog[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [stepWork, setStepWork] = useState<StepWork[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [streak, setStreak] = useState<Streak>({ current: 0, longest: 0, lastCheckInDate: null });
  const [journalCount, setJournalCount] = useState(0);

  // 1. Initialize User & Load State
  useEffect(() => {
    const init = async () => {
      // Fetch User
      const currentUser = await getCurrentUser();
      setUser(currentUser);

      // Fetch WP State (Logs, Settings, etc.)
      const state = await loadState(currentUser.isLoggedIn);
      if (state) {
        setSobrietyDate(state.sobrietyDate);
        setLogs(state.logs || []);
        setContacts(state.contacts || []);
        setStepWork(state.sponsors || []); // 'sponsors' maps to stepWork in UI
        setBadges(state.badges || []);
        setStreak(state.streak || { current: 0, longest: 0, lastCheckInDate: null });
        setJournalCount(state.journalCount || 0);
      }
      setIsLoading(false);
    };

    init();
  }, []);

  // 2. Sync Journal from Firebase (Separate stream)
  useEffect(() => {
    if (!user) return;
    // Subscribe to realtime updates if logged in
    const unsubscribe = subscribeToJournals(user, (entries) => {
        setJournals(entries);
    });
    return () => unsubscribe();
  }, [user]);

  // 3. Save State Effect (Debounced or on change)
  useEffect(() => {
    if (isLoading || !user) return;
    
    const currentState: WPState = {
        logs,
        contacts,
        sponsors: stepWork,
        sobrietyDate,
        badges,
        streak,
        journalCount,
        chatCount: 0 // handled by chat component mostly
    };

    // Save to WP (or local fallback)
    saveState(currentState, user.isLoggedIn);
  }, [logs, contacts, stepWork, sobrietyDate, badges, streak, journalCount, user, isLoading]);


  // Responsive handler
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Badge Logic Helpers
  const awardBadge = (key: string, label: string) => {
      if (badges.find(b => b.key === key)) return;
      const newBadge: Badge = { id: Date.now().toString(), key, label, earnedAt: new Date().toISOString(), icon: '🏅' };
      setBadges(prev => [...prev, newBadge]);
      alert(`🎉 You earned a badge: ${label}`);
  };

  const handleAddJournal = (entry: JournalEntry) => {
    // Update local state directly as fallback for when real-time sync is unavailable
    setJournals(prev => [entry, ...prev]);
    
    const newCount = journalCount + 1;
    setJournalCount(newCount);
    
    if (newCount === 1) awardBadge('first_journal', 'First Journal Entry');
    if (newCount === 5) awardBadge('five_journals', '5 Journal Entries');
  };

  const handleCheckIn = () => {
    const newLog: MeetingLog = { id: Date.now().toString(), timestamp: new Date().toISOString(), type: 'Check-In', location: 'GPS' };
    setLogs(prev => [newLog, ...prev]);
    
    // Update Streak
    const today = new Date().toISOString().slice(0,10);
    const last = streak.lastCheckInDate;
    let newCurrent = streak.current;
    
    if (!last) {
        newCurrent = 1;
    } else {
        const lastDate = new Date(last);
        const todayDate = new Date(today);
        const diffDays = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) newCurrent += 1;
        else if (diffDays > 1) newCurrent = 1;
        // if diffDays === 0, same day, do nothing to streak count
    }

    const newStreak = {
        current: newCurrent,
        longest: Math.max(newCurrent, streak.longest),
        lastCheckInDate: today
    };
    setStreak(newStreak);

    // Badges based on logs/streak
    const logCount = logs.filter(l => l.type === 'Check-In').length + 1;
    if (logCount === 1) awardBadge('first_meeting', 'First Check-In');
    if (logCount === 7) awardBadge('seven_meetings', '7 Meetings Logged');
    if (logCount === 30) awardBadge('thirty_meetings', '30 Meetings Logged');
    if (newCurrent === 7) awardBadge('seven_streak', '7-Day Streak');
    if (newCurrent === 30) awardBadge('thirty_streak', '30-Day Streak');

    alert("Checked in successfully!");
  };

  const handleCheckOut = () => {
      const newLog: MeetingLog = { id: Date.now().toString(), timestamp: new Date().toISOString(), type: 'Check-Out' };
      setLogs(prev => [newLog, ...prev]);
      alert("Checked out.");
  };

  const handleAddContact = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const newContact: Contact = {
          id: Date.now().toString(),
          name: formData.get('name') as string,
          phone: formData.get('phone') as string,
          role: formData.get('role') as Contact['role'],
          fellowship: formData.get('fellowship') as Contact['fellowship']
      };
      setContacts(prev => [...prev, newContact]);
      (e.target as HTMLFormElement).reset();
  };

  if (isLoading) {
      return <div className="h-screen flex items-center justify-center bg-penda-cream text-penda-purple">Loading your recovery buddy...</div>;
  }

  const renderContent = () => {
    switch (view) {
      case View.DASHBOARD:
        return <Dashboard sobrietyDate={sobrietyDate} setSobrietyDate={setSobrietyDate} journals={journals} streakCount={streak.current} />;
      case View.MEETINGS:
        return <MeetingFinder logs={logs} onCheckIn={handleCheckIn} onCheckOut={handleCheckOut} />;
      case View.AI_COACH:
        return <AICoach />;
      case View.JOURNAL:
        return <Journal entries={journals} addEntry={handleAddJournal} user={user!} />;
      case View.STEPWORK:
        return <StepWorkComponent 
            stepWorkList={stepWork} 
            saveStepWork={(w) => setStepWork(prev => [...prev, w])}
            deleteStepWork={(id) => setStepWork(prev => prev.filter(i => i.id !== id))} 
        />;
      case View.READINGS:
          return <Readings />;
      case View.BADGES:
          return <Badges badges={badges} streak={streak} />;
      case View.CONTACTS:
          return (
              <div className="space-y-6">
                  <header><h2 className="text-2xl font-bold text-penda-purple">Phone Book</h2></header>
                  <div className="bg-penda-bg p-3 rounded-firm border border-dashed border-penda-light text-xs text-penda-text">
                    {user?.isLoggedIn ? "Your contacts are saved to your account." : "Log in to save your contacts securely."}
                  </div>
                  <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white p-5 rounded-soft shadow-sm border border-penda-border">
                          <h3 className="font-bold text-penda-purple mb-4">Add Contact</h3>
                          <form onSubmit={handleAddContact} className="space-y-3">
                              <label className="block text-xs font-medium text-penda-light">Name</label>
                              <input required name="name" className="w-full p-2 border border-penda-border rounded-firm" />
                              <label className="block text-xs font-medium text-penda-light">Phone</label>
                              <input required name="phone" className="w-full p-2 border border-penda-border rounded-firm" />
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-xs font-medium text-penda-light mb-1">Role</label>
                                    <select name="role" className="w-full p-2 border border-penda-border rounded-firm bg-white">
                                        <option>Sponsor</option><option>Peer</option><option>Therapist</option><option>Family</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-penda-light mb-1">Fellowship</label>
                                    <select name="fellowship" className="w-full p-2 border border-penda-border rounded-firm bg-white">
                                        <option>AA</option><option>NA</option><option>CA</option><option>Other</option>
                                    </select>
                                </div>
                              </div>
                              <button type="submit" className="w-full bg-penda-purple text-white py-2 rounded-firm hover:bg-penda-light mt-2 text-sm">Save Contact</button>
                          </form>
                      </div>
                      <div className="space-y-3">
                          {contacts.map(c => (
                              <div key={c.id} className="bg-white p-4 rounded-firm shadow-sm border border-penda-border flex justify-between items-center">
                                  <div>
                                      <div className="font-bold text-penda-text">{c.name}</div>
                                      <div className="text-xs text-penda-light">{c.role} • {c.fellowship}</div>
                                  </div>
                                  <a href={`tel:${c.phone}`} className="bg-white border border-penda-purple text-penda-purple p-2 rounded-full hover:bg-penda-bg"><Phone size={18}/></a>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>
          );
      case View.HELP:
          return (
              <div className="space-y-6 max-w-2xl mx-auto text-center pt-8">
                  <Siren size={64} className="text-red-500 mx-auto animate-pulse" />
                  <h2 className="text-3xl font-bold text-penda-text">Immediate Crisis Support</h2>
                  <p className="text-penda-light">If you are in crisis or need immediate help, these options can connect you now.</p>
                  
                  <div className="space-y-4 mt-6">
                      <a href="tel:988" className="block w-full bg-red-600 text-white p-4 rounded-firm text-xl font-bold hover:bg-red-700 shadow-lg">
                          📞 CALL 988 NOW
                      </a>
                      <a href="sms:988" className="block w-full bg-white border-2 border-red-600 text-red-600 p-4 rounded-firm text-lg font-bold hover:bg-red-50">
                          💬 TEXT 988
                      </a>
                      <a href="https://findtreatment.gov/" target="_blank" className="block w-full bg-penda-text text-white p-4 rounded-firm text-lg font-bold hover:bg-gray-800">
                          🏥 FIND TREATMENT NEAR YOU
                      </a>
                  </div>
              </div>
          );
      default:
        return <div>Not found</div>;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-penda-cream">
      <Sidebar 
        currentView={view} 
        setView={setView} 
        isMobile={isMobile} 
        isLoggedIn={user?.isLoggedIn || false}
      />
      
      <main className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8 relative">
        {/* Top Header with User Info */}
        <div className="flex justify-between items-center mb-6">
            <h1 className="md:hidden font-bold text-penda-purple">My Recovery Buddy</h1>
            <div className="flex items-center gap-3 ml-auto">
                {view !== View.HELP && (
                    <button 
                        onClick={() => setView(View.HELP)}
                        className="bg-white text-red-600 px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2 hover:bg-red-50 transition-colors shadow-sm border border-red-200"
                    >
                        <AlertCircle size={14} /> Help
                    </button>
                )}
                {user && (
                    <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-penda-border shadow-sm">
                        <a href="/membership-account/your-profile/" className="flex items-center gap-2 hover:opacity-80">
                           <img src={user.avatar} alt="Profile" className="w-6 h-6 rounded-full" />
                           <span className="text-xs font-medium text-penda-purple hidden md:inline">{user.displayName}</span>
                        </a>
                        
                        {user.isLoggedIn ? (
                           <a href="/wp-login.php?action=logout&redirect_to=/" className="ml-2 text-penda-light hover:text-penda-purple" title="Log Out">
                             <LogOut size={14} />
                           </a>
                        ) : (
                           <a href="/login/" className="ml-2 text-penda-light hover:text-penda-purple flex items-center gap-1 text-xs">
                             <LogIn size={14} /> Sign In
                           </a>
                        )}
                    </div>
                )}
            </div>
        </div>

        
        <div className="max-w-4xl mx-auto">
            {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;