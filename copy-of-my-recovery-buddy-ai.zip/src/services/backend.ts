import firebase from 'firebase/compat/app';
import { auth, db } from '../firebase';
import { UserProfile, JournalEntry, AppState } from '../types';

const DEFAULT_STATE: AppState = {
  logs: [],
  contacts: [],
  sponsors: [],
  sobrietyDate: null,
  badges: [],
  streak: { current: 0, longest: 0, lastCheckInDate: null },
  journalCount: 0,
  chatCount: 0
};

// --- AUTH SERVICES ---

export const subscribeToAuthChanges = (callback: (user: UserProfile | null) => void) => {
  return auth.onAuthStateChanged((firebaseUser) => {
    if (firebaseUser) {
      const user: UserProfile = {
        id: firebaseUser.uid,
        displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Member',
        email: firebaseUser.email || '',
        avatar: firebaseUser.photoURL || `https://ui-avatars.com/api/?name=${firebaseUser.email}&background=7A0050&color=fff`,
        isLoggedIn: true
      };
      callback(user);
    } else {
      // Guest User
      callback({
        id: 'guest',
        displayName: 'Guest',
        email: '',
        avatar: 'https://secure.gravatar.com/avatar/?s=96&d=mm&r=g',
        isLoggedIn: false
      });
    }
  });
};

export const loginUser = async (email: string, pass: string) => {
  await auth.signInWithEmailAndPassword(email, pass);
};

export const registerUser = async (email: string, pass: string, name: string) => {
  const cred = await auth.createUserWithEmailAndPassword(email, pass);
  if (cred.user) {
    await cred.user.updateProfile({ displayName: name });
  }
};

export const logoutUser = async () => {
  await auth.signOut();
};

// --- DATA SYNC SERVICE ---

export const loadState = async (user: UserProfile): Promise<AppState> => {
  if (!user.isLoggedIn) {
    const local = localStorage.getItem('mrb_local_state');
    return local ? { ...DEFAULT_STATE, ...JSON.parse(local) } : DEFAULT_STATE;
  }

  try {
    const docSnap = await db.collection('users').doc(user.id).get();
    if (docSnap.exists) {
      return { ...DEFAULT_STATE, ...docSnap.data() } as AppState;
    }
  } catch (e) {
    console.warn("Error loading state from Firebase", e);
  }
  
  return DEFAULT_STATE;
};

export const saveState = async (state: AppState, user: UserProfile): Promise<void> => {
  // Always save locally as backup
  localStorage.setItem('mrb_local_state', JSON.stringify(state));

  if (!user.isLoggedIn) return;

  try {
    await db.collection('users').doc(user.id).set(state, { merge: true });
  } catch (e) {
    console.error("Error saving state to Firebase", e);
  }
};

// --- JOURNAL SERVICE ---

export const saveJournalEntry = async (entry: JournalEntry, user: UserProfile) => {
  if (!user.isLoggedIn) {
    const key = `mrb_journals_guest`;
    const stored = localStorage.getItem(key);
    const journals = stored ? JSON.parse(stored) : [];
    journals.unshift(entry);
    localStorage.setItem(key, JSON.stringify(journals));
    return;
  }

  try {
    await db.collection('journals').add({
      ...entry,
      userId: user.id,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  } catch (e) {
    console.error("Error saving journal to Firebase", e);
  }
};

export const subscribeToJournals = (user: UserProfile, callback: (entries: JournalEntry[]) => void) => {
  if (!user.isLoggedIn) {
    const key = `mrb_journals_guest`;
    const stored = localStorage.getItem(key);
    callback(stored ? JSON.parse(stored) : []);
    return () => {};
  }

  return db.collection('journals')
    .where('userId', '==', user.id)
    .orderBy('createdAt', 'desc')
    .limit(50)
    .onSnapshot((snapshot) => {
      const entries = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id,
        date: doc.data().createdAt?.toDate ? doc.data().createdAt.toDate().toISOString() : new Date().toISOString()
      })) as JournalEntry[];
      callback(entries);
    });
};
