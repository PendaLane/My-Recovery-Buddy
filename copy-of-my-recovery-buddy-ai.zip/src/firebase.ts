import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBJ0PAdWplp8X_VJSb5_viJoyF_CWqCtX0",
  authDomain: "myrecoverybuddy-25e3c.firebaseapp.com",
  projectId: "myrecoverybuddy-25e3c",
  storageBucket: "myrecoverybuddy-25e3c.firebasestorage.app",
  messagingSenderId: "543776149340",
  appId: "1:543776149340:web:2b8587b843bc8e5c7e7b99",
  measurementId: "G-RWFF57D95P"
};

const app = firebase.initializeApp(firebaseConfig);
export const auth = app.auth();
export const db = app.firestore();
export default app;
