
import React, { useState } from 'react';
import { LogIn, UserPlus, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { loginUser, registerUser } from '../services/backend';

interface AuthProps {
  onCancel: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onCancel }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      if (isLogin) {
        await loginUser(email, password);
      } else {
        await registerUser(email, password, name);
      }
      // Success is handled by the Auth Listener in App.tsx
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/invalid-credential') setError('Invalid email or password.');
      else if (err.code === 'auth/email-already-in-use') setError('Email already in use.');
      else if (err.code === 'auth/weak-password') setError('Password should be at least 6 characters.');
      else setError('An error occurred. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] p-4 animate-in fade-in zoom-in-95 duration-300">
      <div className="w-full max-w-md bg-white rounded-soft shadow-lg border border-penda-border overflow-hidden">
        <div className="bg-penda-bg p-6 text-center border-b border-penda-border">
          <h2 className="text-2xl font-bold text-penda-purple">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h2>
          <p className="text-sm text-penda-light mt-1">
            {isLogin ? 'Sign in to access your recovery buddy.' : 'Join free to sync your progress.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-firm text-sm flex items-center gap-2">
              <AlertCircle size={16} /> {error}
            </div>
          )}

          {!isLogin && (
            <div>
              <label className="block text-xs font-bold text-penda-light mb-1 uppercase">Name</label>
              <input 
                type="text" 
                required 
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full p-3 rounded-firm border border-penda-border focus:outline-none focus:border-penda-purple"
                placeholder="How should we call you?"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-penda-light mb-1 uppercase">Email</label>
            <input 
              type="email" 
              required 
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full p-3 rounded-firm border border-penda-border focus:outline-none focus:border-penda-purple"
              placeholder="you@example.com"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-penda-light mb-1 uppercase">Password</label>
            <input 
              type="password" 
              required 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full p-3 rounded-firm border border-penda-border focus:outline-none focus:border-penda-purple"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full bg-penda-purple text-white py-3 rounded-firm font-bold hover:bg-penda-light transition-colors flex items-center justify-center gap-2 disabled:opacity-70 mt-2"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20}/> : (isLogin ? <LogIn size={20}/> : <UserPlus size={20}/>)}
            {isLogin ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="p-4 bg-gray-50 border-t border-penda-border text-center">
          <button 
            type="button"
            onClick={() => { setError(''); setIsLogin(!isLogin); }}
            className="text-sm text-penda-purple font-medium hover:underline"
          >
            {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
          </button>
        </div>
      </div>

      <button onClick={onCancel} className="mt-6 text-penda-light text-sm hover:text-penda-purple flex items-center gap-1 font-medium transition-colors">
        Continue as Guest <ArrowRight size={14} />
      </button>
    </div>
  );
};
